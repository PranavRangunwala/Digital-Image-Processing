# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 13:12:16 2024

@author: RANGUNWALA
"""

import cv2
import numpy as np

image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\Line_Detection_2.jpg', cv2.IMREAD_GRAYSCALE)

horizontal_mask = np.array([[-1, -1, -1],
                            [ 2,  2,  2],
                            [-1, -1, -1]])

vertical_mask = np.array([[-1,  2, -1],
                          [-1,  2, -1],
                          [-1,  2, -1]])

diag_45_mask = np.array([[-1, -1,  2],
                         [-1,  2, -1],
                         [ 2, -1, -1]])

diag_minus_45_mask = np.array([[ 2, -1, -1],
                               [-1,  2, -1],
                               [-1, -1,  2]])

# Apply each filter to the image
response_horizontal = cv2.filter2D(image, -1, horizontal_mask)
response_vertical = cv2.filter2D(image, -1, vertical_mask)
response_45 = cv2.filter2D(image, -1, diag_45_mask)
response_minus_45 = cv2.filter2D(image, -1, diag_minus_45_mask)

# Stack all responses into a single array
responses = np.stack([response_horizontal, response_vertical, response_45, response_minus_45], axis=0)

# Find the maximum response for each pixel across all masks
max_response = np.max(responses, axis=0)

# Threshold the response to highlight strong lines (tuning required based on image)
_, line_detected_image = cv2.threshold(max_response, 128, 255, cv2.THRESH_BINARY)

# Save and display the result
cv2.imwrite('detected_lines.jpg', line_detected_image)
cv2.imshow('Detected Lines', line_detected_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

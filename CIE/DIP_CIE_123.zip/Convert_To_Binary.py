# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 11:55:41 2024

@author: RANGUNWALA
"""

import cv2

image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\cc2.jpg')  # Replace 'input_image.jpg' with the path to your image

gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Convert the grayscale image to binary using a threshold
# Set the threshold to 127, any pixel value above will be white (255), below will be black (0)
_ , binary_image = cv2.threshold(gray_image, 127, 255, cv2.THRESH_BINARY)


cv2.imshow('Original Image', image)
cv2.imshow('Grayscale Image', gray_image)
cv2.imshow('Binary Image', binary_image)
print("dsfegefd" , _)
# Wait until a key is pressed, then close the displayed windows
cv2.waitKey(0)
cv2.destroyAllWindows()

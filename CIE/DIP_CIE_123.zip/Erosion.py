# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 15:34:16 2024

@author: RANGUNWALA
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the input image
input_image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\Erosion_2.jpg')  # Replace 'input_image.jpg' with the path to your image

gray_image = cv2.cvtColor(input_image, cv2.COLOR_BGR2GRAY)

_ , binary_image = cv2.threshold(gray_image, 127, 255, cv2.THRESH_BINARY)


# Define the structuring element (SE)
structuring_element = np.array([
                   [1, 1, 1, 1, 1],
                   [1, 1, 1, 1, 1],
                   [1, 1, 1, 1, 1],
                   [1, 1, 1, 1, 1],
                   [1, 1, 1, 1, 1]], np.uint8)

# OR
#structuring_element = np.ones((5, 5), np.uint8)  # 5x5 square SE


# Perform erosion on the binary image
eroded_image = cv2.erode(binary_image, structuring_element, iterations=7)

# Display the original, binary, and eroded images
plt.figure(figsize=(15, 5))

plt.title('Original Image')
plt.imshow(cv2.cvtColor(input_image, cv2.COLOR_BGR2RGB))
plt.axis('off')
plt.show()

plt.title('Binary Image')
plt.imshow(binary_image, cmap='gray')
plt.axis('off')
plt.show()

plt.title('Eroded Image')
plt.imshow(eroded_image, cmap='gray')
plt.axis('off')

plt.show()

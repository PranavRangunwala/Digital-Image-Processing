# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 12:12:09 2024

@author: RANGUNWALA
"""

import cv2
import numpy as np

# Load the image in grayscale
#image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\IS_2.jpg')

image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\IS_3.jpg', cv2.IMREAD_GRAYSCALE)


# Define the custom Laplacian mask (kernel) for point detection
kernel = np.array([[1, 1, 1],
                   [1, -8, 1],
                   [1, 1, 1]])

# Apply the filter using cv2.filter2D
point_detected_image = cv2.filter2D(image, -1, kernel)


_ , binary_image = cv2.threshold(point_detected_image, 200, 255, cv2.THRESH_BINARY)

# Save and display the result
#cv2.imwrite('detected_points.jpg', point_detected_image)
cv2.imshow('Detected Points', binary_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

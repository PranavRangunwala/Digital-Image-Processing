# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 16:47:21 2024

@author: RANGUNWALA
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 16:20:18 2024

@author: RANGUNWALA
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the input image
input_image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\Closing.jpg')  # Replace with your image path


# Convert the image to grayscale
gray_image = cv2.cvtColor(input_image, cv2.COLOR_BGR2GRAY)

# Convert the grayscale image to a binary image
_, binary_image = cv2.threshold(gray_image, 127, 255, cv2.THRESH_BINARY)

# Define the structuring element (SE)
structuring_element = np.ones((5, 5), np.uint8)  # 5x5 square SE

# Perform erosion followed by dilation (Opening)
dile_Image = cv2.dilate(binary_image, structuring_element, iterations=3)
Closing_image = cv2.erode(dile_Image, structuring_element, iterations=3)


# Display the original, binary, and opened images

plt.title('Original Image')
plt.imshow(cv2.cvtColor(input_image, cv2.COLOR_BGR2RGB))
plt.axis('off')
plt.show()

plt.title('Binary Image')
plt.imshow(binary_image, cmap='gray')
plt.axis('off')
plt.show()

plt.title('Closed Image')
plt.imshow(Closing_image, cmap='gray')
plt.axis('off')
plt.show()

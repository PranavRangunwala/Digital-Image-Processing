# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 14:39:50 2024

@author: RANGUNWALA
"""

import cv2
import numpy as np
from matplotlib import pyplot as plt

# Load the image and convert it to grayscale
image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\ED_4.jpg')  # Replace with the path to your image
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Define Robert's cross convolution kernels
roberts_cross_x = np.array([[1, 0], [0, -1]], dtype=int)
roberts_cross_y = np.array([[0, 1], [-1, 0]], dtype=int)

# Apply the convolution using cv2.filter2D for both Gx and Gy
Gx = cv2.filter2D(gray_image, -1, roberts_cross_x)
Gy = cv2.filter2D(gray_image, -1, roberts_cross_y)

# Calculate the gradient magnitude |G| = sqrt(Gx^2 + Gy^2)
gradient_magnitude = np.sqrt(np.square(Gx) + np.square(Gy))
gradient_magnitude = np.uint8(gradient_magnitude)

# Calculate the approximate gradient magnitude |G| = |Gx| + |Gy|
approximate_magnitude = np.abs(Gx) + np.abs(Gy)
approximate_magnitude = np.uint8(approximate_magnitude)

# Titles and images to display
titles = ['Original Image', 'Gx', 'Gy', 'Gradient Magnitude', 'Approximate Magnitude']
images = [gray_image, Gx, Gy, gradient_magnitude, approximate_magnitude]

# Loop through each image and display it in a separate plot
for i in range(5):
    plt.figure()  # Create a new figure for each image
    plt.imshow(images[i], cmap='gray')
    plt.title(titles[i])
    plt.xticks([]), plt.yticks([])  # Hide ticks
    plt.show()  # Display the figure

gradient_magnitude_normalized = cv2.normalize(gradient_magnitude, None, 0, 255, cv2.NORM_MINMAX)
approximate_magnitude_normalized = cv2.normalize(approximate_magnitude, None, 0, 255, cv2.NORM_MINMAX)

rgm = cv2.resize(gradient_magnitude_normalized, (800,500))
ram = cv2.resize(approximate_magnitude_normalized, (800,500))

# Display using cv2.imshow
cv2.imshow('Gradient Magnitude', rgm)
cv2.imshow('Approximate Magnitude', ram)

cv2.waitKey(0)
cv2.destroyAllWindows()
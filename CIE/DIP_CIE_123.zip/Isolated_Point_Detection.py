# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 13:04:38 2024

@author: RANGUNWALA
"""

import cv2
import numpy as np

# Load the image in grayscale
image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\IS_3.jpg', cv2.IMREAD_GRAYSCALE)

# Apply a slight Gaussian blur to reduce noise and suppress boundary response
blurred_image = cv2.GaussianBlur(image, (3, 3), 0)

# Define the custom Laplacian mask (kernel) for point detection
kernel = np.array([[1, 1, 1],
                   [1, -8, 1],
                   [1, 1, 1]])

# Apply the filter using cv2.filter2D
filtered_image = cv2.filter2D(blurred_image, -1, kernel)

# Apply a threshold to detect isolated points and remove boundaries
_, thresholded_image = cv2.threshold(filtered_image, 128, 255, cv2.THRESH_BINARY)

# Save and display the result
cv2.imwrite('detected_isolated_points.jpg', thresholded_image)
cv2.imshow('Isolated Points Detected', thresholded_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

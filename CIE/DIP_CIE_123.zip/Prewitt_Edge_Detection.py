import cv2
import numpy as np
from matplotlib import pyplot as plt

# Load the image and convert it to grayscale
image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\ED_4.jpg')  # Replace with the path to your image
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Define Prewitt convolution kernels

prewitt_x = np.array([[1, 1, 1],
                      [0, 0, 0],
                      [-1, -1, -1]], dtype=int)

prewitt_y = np.array([[1, 0, -1],
                      [1, 0, -1],
                      [1, 0, -1]], dtype=int)

# Apply the convolution using cv2.filter2D for both Gx and Gy
Gx = cv2.filter2D(gray_image, -1, prewitt_x)
Gy = cv2.filter2D(gray_image, -1, prewitt_y)

# Calculate the gradient magnitude |G| = sqrt(Gx^2 + Gy^2)
gradient_magnitude = np.sqrt(np.square(Gx) + np.square(Gy))
gradient_magnitude = np.uint8(gradient_magnitude)

# Calculate the approximate gradient magnitude |G| = |Gx| + |Gy|
approximate_magnitude = np.abs(Gx) + np.abs(Gy)
approximate_magnitude = np.uint8(approximate_magnitude)

# Display the results
titles = ['Original Image', 'Gx', 'Gy', 'Gradient Magnitude', 'Approximate Magnitude']
images = [gray_image, Gx, Gy, gradient_magnitude, approximate_magnitude]

for i in range(6):
    plt.figure()  # Create a new figure for each image
    plt.imshow(images[i], cmap='gray')
    plt.title(titles[i])
    plt.xticks([]), plt.yticks([])
    plt.show()

# Optionally, save the results
cv2.imshow('prewitt_gradient_magnitude.jpg', gradient_magnitude)
cv2.imshow('prewitt_approximate_magnitude.jpg', approximate_magnitude)

cv2.waitKey(0)
cv2.destroyAllWindows()

# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 15:33:19 2024

@author: RANGUNWALA
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the input image
input_image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\Dilation.jpg') 

# Convert the image to grayscale
gray_image = cv2.cvtColor(input_image, cv2.COLOR_BGR2GRAY)

# Convert the grayscale image to a binary image
_, binary_image = cv2.threshold(gray_image, 127, 255, cv2.THRESH_BINARY)

# Define the structuring element (SE)
structuring_element = np.ones((3, 3), np.uint8)  # 5x5 square SE

# Perform dilation on the binary image
dilated_image = cv2.dilate(binary_image, structuring_element, iterations=5)

# Display the original, binary, and dilated images
plt.figure(figsize=(15, 5))

plt.title('Original Image')
plt.imshow(cv2.cvtColor(input_image, cv2.COLOR_BGR2RGB))
plt.axis('off')
plt.show()

plt.title('Binary Image')
plt.imshow(binary_image, cmap='gray')
plt.axis('off')
plt.show()

plt.title('Dilated Image')
plt.imshow(dilated_image, cmap='gray')
plt.axis('off')

plt.tight_layout()
plt.show()

cv2.imshow("winname", dilated_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

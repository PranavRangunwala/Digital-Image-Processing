# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 14:19:55 2024

@author: RANGUNWALA
"""

import cv2
import numpy as np

# Load the image in grayscale
image = cv2.imread(r'C:\Users\RANGUNWALA\Downloads\ED_4.jpg', cv2.IMREAD_GRAYSCALE)

# Apply Sobel operator to find gradients in X and Y directions
Gx = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)  # Gradient in X direction
Gy = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)  # Gradient in Y direction

# Compute the gradient magnitude (exact method)
magnitude = np.sqrt(Gx**2 + Gy**2)

# Normalize the magnitude to fit in the range [0, 255] for display
magnitude = cv2.normalize(magnitude, None, 0, 255, cv2.NORM_MINMAX)

# Approximate magnitude (faster method)
approx_magnitude = cv2.convertScaleAbs(Gx) + cv2.convertScaleAbs(Gy)

#resized_magnitude = cv2.resize(magnitude, (600, 600))
#resized_approx_magnitude = cv2.resize(approx_magnitude, (600, 600))
#_, edge_detected_image = cv2.threshold(approx_magnitude, 127, 255, cv2.THRESH_BINARY)
cv2.imshow('Exact Magnitude', magnitude)
cv2.imshow('Approximate Magnitude',approx_magnitude)

cv2.waitKey(0)
cv2.destroyAllWindows()
